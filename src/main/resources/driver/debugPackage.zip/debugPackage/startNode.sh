echo "开始关闭进程:"
port='7890'
pid=`lsof -i :$port | grep -i LISTEN | awk '{print $2}'`
if test -z $pid
then
	echo -e "\033[42m当前端口${port}没有被占用!\033[0m"
else
    echo -e "\033[47;31m当前端口${port}被进程${pid}占用!\033[0m"
    kill -9 ${pid}
fi
echo "为chromedriver添加信任"
xattr -d com.apple.quarantine chromedriver
echo "为geckodriver添加信任"
xattr -d com.apple.quarantine geckodriver
echo "开始启动node节点:"
java -jar selenium-server-standalone-3.141.59.jar -role node -hub http://47.100.78.246:2234/grid/register/ -port ${port}